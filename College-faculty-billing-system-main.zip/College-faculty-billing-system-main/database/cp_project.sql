-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 21, 2024 at 05:55 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cp_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_details`
--

CREATE TABLE `admin_details` (
  `Username` varbinary(20) NOT NULL,
  `Password` varbinary(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_details`
--

INSERT INTO `admin_details` (`Username`, `Password`) VALUES
(0x41646d696e, 0x2432792431302453504b2e32353153666b6354444f794a6a345337357543393544715356546875744935396c53534c4d334f52674a4a48766b6b6d32);

-- --------------------------------------------------------

--
-- Table structure for table `assign_subjects`
--

CREATE TABLE `assign_subjects` (
  `Faculty_id` varchar(20) NOT NULL,
  `Scheme` char(5) NOT NULL,
  `Class` varchar(5) NOT NULL,
  `Subject` varchar(10) NOT NULL,
  `TH/PR` varchar(10) NOT NULL,
  `Batch_1` char(1) NOT NULL,
  `Batch_2` char(1) NOT NULL,
  `Batch_3` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `district`
--

CREATE TABLE `district` (
  `District` varchar(30) NOT NULL,
  `State` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `district`
--

INSERT INTO `district` (`District`, `State`) VALUES
('Nanded', 'Maharashtra');

-- --------------------------------------------------------

--
-- Table structure for table `faculty_details`
--

CREATE TABLE `faculty_details` (
  `Faculty_id` varchar(20) NOT NULL,
  `First_name` text NOT NULL,
  `Middle_name` text NOT NULL,
  `Last_name` text NOT NULL,
  `Phone_no` bigint(10) NOT NULL,
  `Gender` text NOT NULL,
  `House_no` varchar(20) NOT NULL,
  `Area` varchar(50) NOT NULL,
  `Landmark` varchar(50) NOT NULL,
  `City` text NOT NULL,
  `District` varchar(20) NOT NULL,
  `Course` varchar(15) NOT NULL,
  `Branch` varchar(50) NOT NULL,
  `Grade` text NOT NULL,
  `Other` varchar(50) NOT NULL,
  `Pan_no` varchar(15) NOT NULL,
  `Aadhaar_no` bigint(15) NOT NULL,
  `Bank_name` text NOT NULL,
  `Bank_address` varchar(50) NOT NULL,
  `Bank_ifsc` varchar(10) NOT NULL,
  `Account_no` bigint(20) NOT NULL,
  `Account_type` text NOT NULL,
  `Micr_code` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faculty_details`
--

INSERT INTO `faculty_details` (`Faculty_id`, `First_name`, `Middle_name`, `Last_name`, `Phone_no`, `Gender`, `House_no`, `Area`, `Landmark`, `City`, `District`, `Course`, `Branch`, `Grade`, `Other`, `Pan_no`, `Aadhaar_no`, `Bank_name`, `Bank_address`, `Bank_ifsc`, `Account_no`, `Account_type`, `Micr_code`) VALUES
('GPAN202459892', 'nikhil', 'vitthal', 'kandhare', 9112430021, 'Male', 'mayakant', 'dhamangaoroad', 'hhh', 'hhhh', 'Nanded', 'B.E./B.Tech.', 'co', 'First class with Distinction', '', 'MSTPK4215J', 202429101608, 'BANK OF CANDA', 'YOYO NAGER', 'SBIN000699', 123456789101, 'Saving Account', '123456789');

-- --------------------------------------------------------

--
-- Table structure for table `faculty_login`
--

CREATE TABLE `faculty_login` (
  `Faculty_id` varbinary(15) NOT NULL,
  `First_name` text NOT NULL,
  `Middle_name` text NOT NULL,
  `Last_name` text NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varbinary(100) NOT NULL,
  `Status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faculty_login`
--

INSERT INTO `faculty_login` (`Faculty_id`, `First_name`, `Middle_name`, `Last_name`, `Email`, `Password`, `Status`) VALUES
(0x4750414e323032343539383932, 'nikhil', 'vitthal', 'kandhare', 'graminpoly123@gmail.com', 0x243279243130244f6869307339426f6d344f705538364a67784454674f79734345774d7864312e704839394b66344e544b6c3277316f527879436875, 'Applied');

-- --------------------------------------------------------

--
-- Table structure for table `gpan202459892bill`
--

CREATE TABLE `gpan202459892bill` (
  `Bill_id` varchar(30) NOT NULL,
  `Date` date DEFAULT NULL,
  `Apdate` date DEFAULT NULL,
  `Month` varchar(10) NOT NULL,
  `Year` varchar(6) NOT NULL,
  `Subject` varchar(25) DEFAULT NULL,
  `Class` varchar(25) DEFAULT NULL,
  `Total_th_hours` int(5) DEFAULT NULL,
  `Total_pr_hours` int(5) DEFAULT NULL,
  `Th_rate` int(11) NOT NULL,
  `Pr_rate` int(11) NOT NULL,
  `Total_amount_of_th` int(11) DEFAULT NULL,
  `Total_amount_of_pr` int(11) DEFAULT NULL,
  `Total_amount` int(11) DEFAULT NULL,
  `Status` text NOT NULL,
  `Reason` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rate_details`
--

CREATE TABLE `rate_details` (
  `Sr_no` int(11) NOT NULL,
  `Th_rate` int(11) NOT NULL,
  `Pr_rate` int(11) NOT NULL,
  `Limit` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rate_details`
--

INSERT INTO `rate_details` (`Sr_no`, `Th_rate`, `Pr_rate`, `Limit`) VALUES
(1, 500, 250, 16000);

-- --------------------------------------------------------

--
-- Table structure for table `scheme_details`
--

CREATE TABLE `scheme_details` (
  `Scheme` varchar(5) NOT NULL,
  `Subject` varchar(10) NOT NULL,
  `Sem` int(1) NOT NULL,
  `TH/PR` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ttgpan202459892`
--

CREATE TABLE `ttgpan202459892` (
  `Scheme` varchar(20) NOT NULL,
  `Days` varchar(10) NOT NULL,
  `Time_from` float(10,2) NOT NULL,
  `Time_to` float(10,2) NOT NULL,
  `Subject` varchar(10) NOT NULL,
  `Class` varchar(10) NOT NULL,
  `Sem` int(1) NOT NULL,
  `TH/PR` varchar(5) NOT NULL,
  `Batch` varchar(10) NOT NULL,
  `Rn/Ln` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_details`
--
ALTER TABLE `admin_details`
  ADD PRIMARY KEY (`Username`);

--
-- Indexes for table `assign_subjects`
--
ALTER TABLE `assign_subjects`
  ADD PRIMARY KEY (`Faculty_id`,`Scheme`,`Class`,`Subject`,`TH/PR`);

--
-- Indexes for table `district`
--
ALTER TABLE `district`
  ADD PRIMARY KEY (`District`);

--
-- Indexes for table `faculty_details`
--
ALTER TABLE `faculty_details`
  ADD PRIMARY KEY (`Faculty_id`),
  ADD KEY `faculty_details_ibfk_1` (`District`);

--
-- Indexes for table `faculty_login`
--
ALTER TABLE `faculty_login`
  ADD PRIMARY KEY (`Faculty_id`);

--
-- Indexes for table `gpan202459892bill`
--
ALTER TABLE `gpan202459892bill`
  ADD PRIMARY KEY (`Bill_id`);

--
-- Indexes for table `rate_details`
--
ALTER TABLE `rate_details`
  ADD PRIMARY KEY (`Sr_no`);

--
-- Indexes for table `scheme_details`
--
ALTER TABLE `scheme_details`
  ADD PRIMARY KEY (`Scheme`,`Subject`,`Sem`);

--
-- Indexes for table `ttgpan202459892`
--
ALTER TABLE `ttgpan202459892`
  ADD PRIMARY KEY (`Days`,`Time_from`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `faculty_details`
--
ALTER TABLE `faculty_details`
  ADD CONSTRAINT `faculty_details_ibfk_1` FOREIGN KEY (`District`) REFERENCES `district` (`District`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
